import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.UUID;
import java.rmi.server.UID;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class signup
 */
@WebServlet("/signup")
public class signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public signup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// JDBC driver name and database URL
	      final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	       final String DB_URL="jdbc:mysql://localhost:3306/4said";

	      //  Database credentials
	      final String USER = "root";
	       final String PASS = "moshesha";
	       PrintWriter out = response.getWriter();
	       Connection conn=null;
	       Statement stmt=null;
	       try {
	           // Register JDBC driver
	           Class.forName("com.mysql.jdbc.Driver");

	           // Open a connection
	          conn = DriverManager.getConnection(DB_URL, USER, PASS);

	           // Execute SQL query
	            stmt = conn.createStatement();
	           String sql;
	          // UUID uniqueKey = UUID.randomUUID();
	           UID userId = new UID();
	           String id=userId.toString();
	           int age=25;
	           String first="tumelo";
	           String last= "ntelekoa";
	           String role="obsever";
	           int phone=58974302;
	           String password="mypassword";
	           sql = "insert into users values (?,?,?,?,?,?,?)";
	           
	           PreparedStatement pst =  conn.prepareStatement(sql);
	           pst.setString(1, id);
	           pst.setLong(2, age);
	           pst.setString(3, first);
	           pst.setString(4, last);
	           pst.setString(5, role);
	           
	           pst.setLong(6, phone);
	           pst.setString(7, password);
	         
	            pst.executeUpdate();
	           
	           pst.close();
	           

	           // Clean-up environment
	           
	           stmt.close();
	           conn.close();
	        } catch(SQLException se) {
	           //Handle errors for JDBC
	           se.printStackTrace();
	        } catch(Exception e) {
	           //Handle errors for Class.forName
	           e.printStackTrace();
	        } finally {
	           //finally block used to close resources
	           try {
	              
				if(stmt!=null)
	                 stmt.close();
	           } catch(SQLException se2) {
	           } // nothing we can do
	           try {
	              if(conn!=null)
	              conn.close();
	           } catch(SQLException se) {
	              se.printStackTrace();
	           } //end finally try
	        } //end try

		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
