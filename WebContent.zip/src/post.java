

import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.server.UID;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class post
 */
@WebServlet("/post")
public class post extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public post() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				// JDBC driver name and database URL
			      final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
			       final String DB_URL="jdbc:mysql://localhost:3306/4said";

			      //  Database credentials
			      final String USER = "root";
			       final String PASS = "moshesha";
			       PrintWriter out = response.getWriter();
			       Connection conn=null;
			       Statement stmt=null;
			       try {
			           // Register JDBC driver
			           Class.forName("com.mysql.jdbc.Driver");

			           // Open a connection
			          conn = DriverManager.getConnection(DB_URL, USER, PASS);

			           // Execute SQL query
			            stmt = conn.createStatement();
			           String sql;
			          // UUID uniqueKey = UUID.randomUUID();
			           UID postId = new UID();
			           String postid=postId.toString();
			           String id="1992";
			           String category="Mobiles";
			           String subcategory="Mobiles";
			           String subsubcategory="Mobiles";
			           String description="hello world";
			           String profilephoto="images/bk4.jpg";
			           String photo1="images/bk4.jpg";
			           String photo2="images/bk4.jpg";
			           String photo3="images/bk4.jpg";
			           double paytype=0.00;
			           int views=0;
			         //  Timestamp  timestamp="";
			           java.sql.Timestamp timestamp = java.sql.Timestamp.valueOf("2007-09-23 10:10:10.0");
			           sql = "insert into posts values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
			           System.out.println("using posts");
			           PreparedStatement pst =  conn.prepareStatement(sql);
			           pst.setString(1, postid);
			           pst.setString(2, id);
			           pst.setString(3, category);
			           pst.setString(4, subcategory);
			           pst.setString(5, subsubcategory);
			           pst.setString(6, description);      
			           pst.setString(7, profilephoto);
			           pst.setString(8, photo1);
			           pst.setString(9, photo2);
			           pst.setString(10, photo3);
			           pst.setDouble(11, paytype);
			           pst.setLong(12, views);
			           pst.setTimestamp(13, timestamp);
			           
			            pst.executeUpdate();
			           
			           pst.close();
			           

			           // Clean-up environment
			           
			           stmt.close();
			           conn.close();
			        } catch(SQLException se) {
			           //Handle errors for JDBC
			           se.printStackTrace();
			        } catch(Exception e) {
			           //Handle errors for Class.forName
			           e.printStackTrace();
			        } finally {
			           //finally block used to close resources
			           try {
			              
						if(stmt!=null)
			                 stmt.close();
			           } catch(SQLException se2) {
			           } // nothing we can do
			           try {
			              if(conn!=null)
			              conn.close();
			           } catch(SQLException se) {
			              se.printStackTrace();
			           } //end finally try
			        } //end try

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
